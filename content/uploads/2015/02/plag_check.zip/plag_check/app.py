# -*- coding: utf-8 -*-

__author__ = 'Nikolai Tschacher'
__version__ = '0.4'
__contact__ = 'hire@incolumitas.com'

import json
import csv
import argparse
import requests
import re
import os
import subprocess
import time
import logging
from datetime import datetime
import sys
import pprint
import configparser
from GoogleScraper import scrape_with_config
from GoogleScraper.output_converter import JsonStreamWriter
from GoogleScraper.scraping import MaliciousRequestDetected, GoogleSearchError

if not os.path.exists('logs/'):
    os.mkdir('logs')

logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

logging.getLogger('PlagChecker').addHandler(logging.StreamHandler())

BASE_PATH = os.path.dirname(os.path.realpath(__file__))

Config = configparser.ConfigParser()
Config.read_file(open(os.path.join(BASE_PATH, 'plag_check.cfg'), 'r'))

if os.path.exists('google_scraper.db'):
    os.remove('google_scraper.db')

result_file = datetime.strftime(datetime.now(), Config['SETTINGS'].get('result_file', 'results_%y%m.log'))

RESULTS_FILE_HANDLE = open(result_file + '.csv', 'w')
RESULTS_FILE = csv.writer(RESULTS_FILE_HANDLE, delimiter=',', quotechar="'")
CSV_HEADER = ('query', 'search_engine', 'plagiarized')
RESULTS_FILE.writerow(CSV_HEADER)

json_stream_writer = JsonStreamWriter(result_file + '.json')

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

file_name = datetime.strftime(datetime.now(), Config['SETTINGS'].get('log_file', 'logfile_%y%m.log'))
logfile_path = os.path.join(BASE_PATH, file_name)

file_handler = logging.FileHandler(logfile_path)
file_handler.setFormatter(formatter)
file_handler.setLevel(Config['SETTINGS'].get('loglevel', 'warning').upper())
logger.addHandler(file_handler)

consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(formatter)
consoleHandler.setLevel(Config['SETTINGS'].get('loglevel_stdout', 'warning').upper())
logger.addHandler(consoleHandler)
logger.setLevel(logging.DEBUG)

REAL_IP = None
CONNECTED = False


def chunk_it(l, n):
    n = max(1, n)
    return [l[i:i + n] for i in range(0, len(l), n)]

def make_chunks(text):
    """Splits the text in chunks suitable for a single search query.

    Google supports only 32 words per query!

    The algorithm works the following way:
        If the phrase has less than 30 words and more than 5 words, take it as one query.
        Otherwise split the phrase in equally long parts, in the same range as above.

    Args:
        The text to check.

    Returns:
        Quoted chunks to use in google.
    """
    # normalize text
    text = text.replace('\n', ' ').replace('\t', ' ')

    chunks = []
    sentences = text.split('.')

    min_words = Config['SETTINGS'].getint('minimum_words', 8)
    max_words = Config['SETTINGS'].getint('maximum_words', 30)

    for sentence in sentences:

        words = re.split(r'\s+', sentence)
        num_words = len(words)

        if num_words in range(min_words, max_words):
            chunks.append('"{}"'.format(' '.join(words).lstrip()))

        elif num_words < min_words:
            pass

        else:
            groups = []
            for i in range(0, num_words, (min_words+1)):
                try:
                    groups.append(words[i:(i+min_words+1)])
                except:
                    groups.append(words[i:])

            groups = [g for g in groups if len(g) > min_words]

            for group in groups:
                chunks.append(
                    '"{}"'.format(' '.join(group).lstrip())
                )

    return chunks


def check_chunk(query, search_engine='bing', mode='http'):
    """Checks the given chunks for plagiarized contents.

    For every chunk, we will return whether the query was found
    literally in the SERP of the search engine.
    """
    # See in the config.cfg file for possible values
    config = {
        'SCRAPING': {
            'keyword': query,
            'use_own_ip': 'True',
            'keyword_file': '',
            'search_engines': search_engine,
            'num_pages_for_keyword': 1,
            'num_results_per_page': 10,
            'scrape_method': mode,
            'raise_exceptions_while_scraping': True
        },
        'SELENIUM': {
            'sel_browser': Config['SETTINGS'].get('browser', 'phantomjs')
        },
        'GLOBAL': {
            'google_sleeping_ranges': '''1: 0, 1''',
            'verbosity': 0,
            'do_caching': Config['SETTINGS'].getboolean('do_caching', True),
            'continue_last_scrape': False
        }
    }

    try:
        search = scrape_with_config(config)
    except Exception as e:
        logger.critical('Unexpected exception: {}'.format(e))
        sys.exit()


    serp = search.serps[0]
    
    if 'Malicious' in serp.status:
        return False

    # if the original query yielded some results and thus was found by the search engine.
    plagiarized = True
    if serp.no_results:
        plagiarized = False

    return query, plagiarized
    
def snippet(string):
    i = len(string)
    if i > 45:
        i = 45
    
    return '"' + string[:i].lstrip('"').rstrip('"') + '..."'

def get_outside_ip():
    """Gets your IP as seen from the web."""
    try:
        text = requests.get(Config['SETTINGS'].get('check_ip_url')).text
        ip_outside = json.loads(text)
        logger.debug('Your current ip address information: {}'.format(pprint.pformat(ip_outside)))
        global REAL_IP
        REAL_IP = ip_outside['ip']
        return ip_outside['ip']
    except:
        pass

def update_ip_change_file():
    with open(Config['SETTINGS'].get('last_hma_ip_change_file', '.hma_ip_change'), 'w') as f:
        f.write(str(int(time.time())))

def read_ip_change_file():
    return open(Config['SETTINGS'].get('last_hma_ip_change_file', '.hma_ip_change'), 'r').read()

def change_ip():
    last_change = int(read_ip_change_file())
    delta = int(time.time()) - last_change
    if (2.5 * 60) < delta:
        subprocess.call([Config['SETTINGS'].get('hma_path'), '-changeip'])
        update_ip_change_file()
        sleep_time = Config['SETTINGS'].getint('change_ip_timeout', 60)
        time.sleep(sleep_time-2)
        logger.info('Changed ip to {}'.format(get_outside_ip()))
    else:
        sleep_for = (3 * 60) - delta
        logger.warning('Changing IP to fast. Last IP change was {} seconds ago. Sleeping {} seconds'.format(delta, sleep_for))
        time.sleep(sleep_for)
        change_ip()
        
        
def check_maxmatch(results, num_chunks, max_match):
    # when we got that many plagiarized chunks, stop searching
    stop_searching_at = (max_match / 100) * num_chunks
    
    return stop_searching_at <= len([p for p in results if p['plagiarized'] is True])


def check_all_queries(chunks, max_match, mode='http'):
    global REAL_IP

    results = []
    num_chunks = len(chunks)
    assert max_match in range(0, 101), 'max_match is invalid percentage! {}'.format(max_match)

    se1 = Config['SETTINGS'].get('first_search_engine', 'duckduckgo')
    se2 = Config['SETTINGS'].get('second_search_engine', 'google')

    search_engines = (se1, se2)

    res = None

    for chunk in chunks:

        for se in search_engines:

            logger.debug('Checking query {} with {}'.format(chunk, se))
            res = check_chunk(chunk, search_engine=se, mode=mode)

            if not res:
                logger.warning('Caught by {}. HMA IP is {}.'.format(se, REAL_IP))
                # try again with different ip
                change_ip()
                res = check_chunk(chunk, search_engine=se, mode=mode)

            if res and res[1] is True:
                break
            elif res and res[1] is False:
                logger.info('[{}] NO PLAGIARY: {}'.format(se, res[0]))

        if res:
            query, plagiarized = res

            if plagiarized is True:
                logger.info('[{}] PLAGIARY: {}'.format(se, query))
                
            results.append({
                'query': query,
                'plagiarized': plagiarized,
                'search_engine': se})
        else:
            logger.warning('Couldnt get info for query {} on search engines {}'.format(chunk, search_engines))

        if check_maxmatch(results, num_chunks, max_match):
            break

    return results


def connect_HMA():
    global CONNECTED
    if not CONNECTED:
        subprocess.call([Config['SETTINGS'].get('hma_path'), '-connect'])
        update_ip_change_file()
        get_outside_ip()
        time.sleep(20-2)
        CONNECTED = True


def using_wrong_ip():
    """Checks whether the current IP that is seen from the web is not
        the same as one configured in the config file."""
    config_ip = Config['SETTINGS'].get('real_ip', None)
    if not config_ip:
        logger.critical('Connection failed: Stopping because no real ip was set. You must set the IP address HMA should NOT WORK with in the config file!')
        sys.exit()

    outside_ip = get_outside_ip()

    return any([outside_ip == ip.strip() for ip in config_ip.split(',') if ip.strip()])


def maybe_start_HMA():
    """Starts HMA.

    start only if we cannot find the name via the command 'wmic process get description,executablepath'!
    """

    cmd = os.popen('wmic process get description,executablepath')
    running_procs = cmd.read()
    cmd.close()

    if not Config['SETTINGS'].get('hma_exe_name') in running_procs:
        hma_path = Config['SETTINGS'].get('hma_path')
        if not os.path.exists(hma_path):
            logger.critical('Path {} is not a valid file name, stopping the application'.format(hma_path))
            sys.exit()

        os.startfile(hma_path)
        time.sleep(30)

def kill_HMA():
    """Kills HMA."""
    subprocess.call('taskkill /f /IM "HMA! Pro VPN.exe"',
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL)
                    
                    
def bing_precheck(chunks):
    
    with open('bing_precheck.txt', 'wt') as f:
        for word in chunks:
            f.write(word + '\n')
        
    # See in the config.cfg file for possible values
    config = {
        'SCRAPING': {
            'keyword_file': 'bing_precheck.txt',
            'search_engines': 'bing',
            'num_pages_for_keyword': 1,
            'scrape_method': 'http-async',
        },
        'GLOBAL': {
            'verbosity': 0,
            'continue_last_scrape': False
        }
    }

    try:
        search = scrape_with_config(config)
    except GoogleSearchError as e:
        logger.error(e)

    results = []
    # let's inspect what we got. Get the last search
    for serp in search.serps:
        plagiarized = False

        if serp.no_results is False and serp.was_correctly_requested():
            plagiarized = True

        results.append({
                'query': serp.query,
                'plagiarized': plagiarized,
                'search_engine': 'bing'})
                
    logger.info('Bing precheck: {}/{} chunks are plagiarized.'.format(len([c for c in results if c['plagiarized'] is True]), len(chunks)))
                
    return results
    

if __name__ == '__main__':

    parser = argparse.ArgumentParser('PlagChecker. A tool to check a text for plagiarism.')
    parser.add_argument('filenames', nargs='+', help='Please specify a file to check for plagiarized content. You may also specify more than one file, then every article is checked.')
    parser.add_argument('-m', '--maxmatch', help='If max_match percent of all chunks are plagiarized, stop the application. Must be an percentage, this means: 0 to 100%.')
    parser.add_argument('-f', '--logfile', help='The name of the logfile. Without datetime formatting.')

    args = parser.parse_args()

    if args.logfile:
        file_handler = logging.FileHandler(args.logfile)
        file_handler.setFormatter(formatter)
        file_handler.setLevel(Config['SETTINGS'].get('loglevel', 'warning').upper())
        logger.addHandler(file_handler)

    # checks whether the outside IP not the one that was set in the config file
    if using_wrong_ip():
        maybe_start_HMA()
        # change ip if HMA is running.
        connect_HMA()

        if using_wrong_ip():
            logger.critical('HMA still doesnt work. turning down.')
            sys.exit()

    json_started = written_one = False

    for i, file in enumerate(args.filenames):

        if os.path.exists(file):

            CSV_HEADER = ('query', 'search_engine', 'plagiarized')

            contents = open(os.path.abspath(file), 'r', errors='ignore').read()
            chunks = make_chunks(contents)

            # this is coded out, ugly but since we'll never user
            # more than three engines, no need for dynamism.
            max_match = Config['SETTINGS'].getfloat('max_match', 100)
            if args.maxmatch:
                max_match = args.maxmatch
                
            mode = Config['SETTINGS'].get('mode', 'http')
            
            results = bing_precheck(chunks)
            
            if not check_maxmatch(results, len(chunks), max_match):
                # take all chunks that bing considered as not plagiarized
                chunks = [r['query'] for r in results if r['plagiarized'] is False]
            
                results = check_all_queries(chunks, int(max_match), mode=mode)

            # what happens when there are zero chunks remaining.
            try:
                percentage_matched = 100 * (len([r for r in results if r['plagiarized'] is True]) / len(chunks))
            except ZeroDivisionError as e:
                percentage_matched = 100 * (len([r for r in results if r['plagiarized'] is True]) / 1)
                
            percentage_matched = round(percentage_matched, 2)
            
            for res in results:
                RESULTS_FILE.writerow((res['query'], res['search_engine'], res['plagiarized']))

            json_stream_writer.write({
                'article_filename': os.path.abspath(file),
                'checked_on': datetime.now().isoformat(),
                'matched_in_percent': percentage_matched,
                'results': results
            })
            written_one = True

            if Config['SETTINGS'].getboolean('print_matched', True):
                print('Matched {}'.format(percentage_matched))

        else:
            logger.critical('Skipping file {}, couldnt be found.'.format(file))

    if written_one:
        json_stream_writer.end()

    RESULTS_FILE_HANDLE.close()
